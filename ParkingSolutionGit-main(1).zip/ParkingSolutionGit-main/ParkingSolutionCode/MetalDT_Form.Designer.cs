﻿
namespace ParkingSolution
{
    partial class MetalDT_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT = new System.Windows.Forms.DataGridView();
            this.Button_Confirm_RadioButton_Pass_MetalDT = new System.Windows.Forms.Button();
            this.NotificationBox = new System.Windows.Forms.Label();
            this.RadioButton_REport_RadioButton_Pass_MetalDT = new System.Windows.Forms.RadioButton();
            this.RadioButton_Pass_RadioButton_Pass_MetalDT = new System.Windows.Forms.RadioButton();
            this.VehicleNumber = new System.Windows.Forms.TextBox();
            this.label_vehicleNumber_MetalDT = new System.Windows.Forms.Label();
            this.button_LogOut = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_NotificationBox_RadioButton_Pass_MetalDT
            // 
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT.Location = new System.Drawing.Point(524, 91);
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT.Name = "dataGridView_NotificationBox_RadioButton_Pass_MetalDT";
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT.Size = new System.Drawing.Size(279, 150);
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT.TabIndex = 14;
            this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT_CellContentClick);
            // 
            // Button_Confirm_RadioButton_Pass_MetalDT
            // 
            this.Button_Confirm_RadioButton_Pass_MetalDT.BackColor = System.Drawing.Color.White;
            this.Button_Confirm_RadioButton_Pass_MetalDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Confirm_RadioButton_Pass_MetalDT.ForeColor = System.Drawing.Color.Black;
            this.Button_Confirm_RadioButton_Pass_MetalDT.Location = new System.Drawing.Point(201, 201);
            this.Button_Confirm_RadioButton_Pass_MetalDT.Name = "Button_Confirm_RadioButton_Pass_MetalDT";
            this.Button_Confirm_RadioButton_Pass_MetalDT.Size = new System.Drawing.Size(147, 40);
            this.Button_Confirm_RadioButton_Pass_MetalDT.TabIndex = 13;
            this.Button_Confirm_RadioButton_Pass_MetalDT.Text = "Confirm";
            this.Button_Confirm_RadioButton_Pass_MetalDT.UseVisualStyleBackColor = false;
            // 
            // NotificationBox
            // 
            this.NotificationBox.AutoSize = true;
            this.NotificationBox.BackColor = System.Drawing.Color.Transparent;
            this.NotificationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NotificationBox.Location = new System.Drawing.Point(553, 59);
            this.NotificationBox.Name = "NotificationBox";
            this.NotificationBox.Size = new System.Drawing.Size(189, 29);
            this.NotificationBox.TabIndex = 12;
            this.NotificationBox.Text = "NotificationBox";
            // 
            // RadioButton_REport_RadioButton_Pass_MetalDT
            // 
            this.RadioButton_REport_RadioButton_Pass_MetalDT.AutoSize = true;
            this.RadioButton_REport_RadioButton_Pass_MetalDT.BackColor = System.Drawing.Color.Transparent;
            this.RadioButton_REport_RadioButton_Pass_MetalDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButton_REport_RadioButton_Pass_MetalDT.Location = new System.Drawing.Point(294, 153);
            this.RadioButton_REport_RadioButton_Pass_MetalDT.Name = "RadioButton_REport_RadioButton_Pass_MetalDT";
            this.RadioButton_REport_RadioButton_Pass_MetalDT.Size = new System.Drawing.Size(120, 35);
            this.RadioButton_REport_RadioButton_Pass_MetalDT.TabIndex = 11;
            this.RadioButton_REport_RadioButton_Pass_MetalDT.TabStop = true;
            this.RadioButton_REport_RadioButton_Pass_MetalDT.Text = "Report";
            this.RadioButton_REport_RadioButton_Pass_MetalDT.UseVisualStyleBackColor = false;
            // 
            // RadioButton_Pass_RadioButton_Pass_MetalDT
            // 
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.AutoSize = true;
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.BackColor = System.Drawing.Color.Transparent;
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.Location = new System.Drawing.Point(163, 153);
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.Name = "RadioButton_Pass_RadioButton_Pass_MetalDT";
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.Size = new System.Drawing.Size(97, 35);
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.TabIndex = 10;
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.TabStop = true;
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.Text = "Pass";
            this.RadioButton_Pass_RadioButton_Pass_MetalDT.UseVisualStyleBackColor = false;
            // 
            // VehicleNumber
            // 
            this.VehicleNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.VehicleNumber.Location = new System.Drawing.Point(201, 86);
            this.VehicleNumber.Multiline = true;
            this.VehicleNumber.Name = "VehicleNumber";
            this.VehicleNumber.Size = new System.Drawing.Size(159, 37);
            this.VehicleNumber.TabIndex = 9;
            this.VehicleNumber.TextChanged += new System.EventHandler(this.VehicleNumber_TextChanged);
            // 
            // label_vehicleNumber_MetalDT
            // 
            this.label_vehicleNumber_MetalDT.AutoSize = true;
            this.label_vehicleNumber_MetalDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_vehicleNumber_MetalDT.Location = new System.Drawing.Point(196, 27);
            this.label_vehicleNumber_MetalDT.Name = "label_vehicleNumber_MetalDT";
            this.label_vehicleNumber_MetalDT.Size = new System.Drawing.Size(178, 25);
            this.label_vehicleNumber_MetalDT.TabIndex = 8;
            this.label_vehicleNumber_MetalDT.Text = "Vehicle Number";
            // 
            // button_LogOut
            // 
            this.button_LogOut.Font = new System.Drawing.Font("Modern No. 20", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_LogOut.Location = new System.Drawing.Point(524, 396);
            this.button_LogOut.Name = "button_LogOut";
            this.button_LogOut.Size = new System.Drawing.Size(256, 42);
            this.button_LogOut.TabIndex = 27;
            this.button_LogOut.Text = "Log Out";
            this.button_LogOut.UseVisualStyleBackColor = true;
            this.button_LogOut.Click += new System.EventHandler(this.button_LogOut_Click);
            // 
            // MetalDT_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_LogOut);
            this.Controls.Add(this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT);
            this.Controls.Add(this.Button_Confirm_RadioButton_Pass_MetalDT);
            this.Controls.Add(this.NotificationBox);
            this.Controls.Add(this.RadioButton_REport_RadioButton_Pass_MetalDT);
            this.Controls.Add(this.RadioButton_Pass_RadioButton_Pass_MetalDT);
            this.Controls.Add(this.VehicleNumber);
            this.Controls.Add(this.label_vehicleNumber_MetalDT);
            this.Name = "MetalDT_Form";
            this.Text = "MetalDT";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_NotificationBox_RadioButton_Pass_MetalDT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_NotificationBox_RadioButton_Pass_MetalDT;
        private System.Windows.Forms.Button Button_Confirm_RadioButton_Pass_MetalDT;
        private System.Windows.Forms.Label NotificationBox;
        private System.Windows.Forms.RadioButton RadioButton_REport_RadioButton_Pass_MetalDT;
        private System.Windows.Forms.RadioButton RadioButton_Pass_RadioButton_Pass_MetalDT;
        private System.Windows.Forms.TextBox VehicleNumber;
        private System.Windows.Forms.Label label_vehicleNumber_MetalDT;
        private System.Windows.Forms.Button button_LogOut;
    }
}