﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingSolution
{
    public partial class Cleaner_Form : Form
    {
        public Cleaner_Form()
        {
            InitializeComponent();
        }

        private void button_Attandance_Cleaner_Click(object sender, EventArgs e)
        {

        }
    }
}
