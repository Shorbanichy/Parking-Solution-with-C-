﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingSolution
{
    public partial class MetalDT_Form : Form
    {
        public MetalDT_Form()
        {
            InitializeComponent();
        }

        private void dataGridView_NotificationBox_RadioButton_Pass_MetalDT_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button_LogOut_Click(object sender, EventArgs e)
        {

        }

        private void VehicleNumber_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
