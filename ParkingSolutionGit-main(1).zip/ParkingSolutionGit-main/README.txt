# ParkingSolution
Welcome to Parking solution

How to run the project
	* This project is written in C# language using Visual Studio 2019
	* This project Data Base created with Microsoft Sql Server Management Studio.
	* Here is the procedure How to setup the data base:
		1. From the DB file select the two File name:
						i)ParkingSolution.mdf
						ii)ParkingSolution_log.ldf
		2. Copy the selected two file and paste in this location:
	C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA
Note: If you have installed your MSSMS in local disk:C . Other wise find the Sql server then go to the Data location then paste this. after pasting please refresh the Data base studio. In Sh Allah It will work.
Replace the connection string name with your own string name inside code where connection string belongs.

Thank you so much.


Author Name: MD ABID HOSSAIN
	    ------------------	
	Mail: abidhossain6781@gmail.com (Mail me if you have any querry)
	      --------------------------	
